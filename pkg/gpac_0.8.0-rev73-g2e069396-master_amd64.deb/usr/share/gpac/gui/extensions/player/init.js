
obj = {
    whoami: "GPAC-GUI-Extension",
    name: "Player",
    icon: "applications-multimedia.svg",
    author: "JeanLF",
    description: "Nice test extension",
    url: "http://foo.bar",
    execjs: ["player.js", "fileopen.js", "playlist.js", "stats.js"],
    autostart: true,
    config_id: "Player",
    requires_gl: false,
    version_major: 1,
    version_minor: 0
};
